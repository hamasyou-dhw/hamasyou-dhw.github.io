this.group = DisplayElement().addChildTo(this)

var gridX = Grid(BOARD_SIZE, MAX_PER_LINE)
var gridY = Grid(BOARD_SIZE, MAX_PER_LINE)

// ブロックの表示
;(BLOCK_NUM).times((i) => {
  // 縦横をにブロックを並べる
  let x = i % MAX_PER_LINE
  let y = Math.floor(i / MAX_PER_LINE)
  let angle = 360 / BLOCK_NUM * i  // 色の変化を等間隔に
  let block = Block(angle).addChildTo(this.group)

  // Grid は 16 箇所に区切られた位置をもつ区画
  // インデックスは0から始まり、span(i) で区画の左上座標が手に入る
  block.x = gridX.span(x) + BOARD_OFFSET_X
  block.y = gridY.span(y) + BOARD_OFFSET_Y
})