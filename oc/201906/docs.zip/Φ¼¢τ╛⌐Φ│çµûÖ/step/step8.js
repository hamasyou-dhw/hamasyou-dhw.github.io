checkHit: function () {
    if (this.ball.left < 0) {
      this.ball.left = 0
      this.ball.reflectX()
    } else if (this.ball.right > this.gridX.width) {
      this.ball.right = this.gridX.width
      this.ball.reflectX()
    }

    if (this.ball.top < 0) {
      this.ball.top = 0
      this.ball.reflectY()
    } else if (this.ball.bottom > this.gridY.width) {
      this.ball.bottom = this.gridY.width
      this.ball.reflectY()
    }

    // パドルとボールの接触
    if (this.ball.hitTestElement(this.paddle)) {
      this.ball.bottom = this.paddle.top

      let dx = this.ball.x - this.paddle.x
      this.ball.direction.x = dx
      this.ball.direction.y = -60
      this.ball.direction.normalize()

      // ボールのスピードアップ
      this.ballSpeed += 1
    }

    // ブロック
    this.group.children.some((block) => {
      if (this.ball.hitTestElement(block)) {
        // ベクトルの引き算（ボールの方向を計算）
        let dq = Vector2.sub(this.ball, block)

        if (Math.abs(dq.x) < Math.abs(dq.y)) {
          this.ball.reflectY()
          if (dq.y >= 0) {
            this.ball.top = block.bottom
          } else {
            this.ball.bottom = block.top
          }
        } else {
          this.ball.reflectX()
          if (dq.x >= 0) {
            this.ball.left = block.right
          } else {
            this.ball.right = block.left
          }
        }

        // ブロックを取り除く
        block.remove()

        return true
      }
    }, this)
  },