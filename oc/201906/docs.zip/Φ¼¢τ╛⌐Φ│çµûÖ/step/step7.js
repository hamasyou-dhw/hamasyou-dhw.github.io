update: function (app) {
    this.paddle.x = app.pointer.x
    if (this.paddle.left < 0) {
      this.paddle.left = 0
    } else if (this.paddle.right > this.gridX.width) {
      this.paddle.right = this.gridX.width
    }

    ;(this.ballSpeed).times(() => {
      this.ball.move()

    // --- ↓ Step.9 のコードを記述する
    // --- ↑ Step.9 ここまで
    })
  },
