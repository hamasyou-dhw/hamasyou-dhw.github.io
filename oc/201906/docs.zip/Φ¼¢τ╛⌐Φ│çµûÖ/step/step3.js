Block(0).setPosition(100, 100).addChildTo(this);
Block(20).setPosition(200, 100).addChildTo(this);
Block(80).setPosition(200, 100).addChildTo(this);