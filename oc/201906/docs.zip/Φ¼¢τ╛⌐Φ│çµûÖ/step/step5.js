phina.define('Ball', {
  superClass: 'CircleShape',
  init: function () {
    this.superInit({
      radius: BALL_RADIUS,
      fill: 'white',
      stroke: null,
      cornerRadius: 8
    })
    this.speed = 0
    this.direction = Vector2(1, -1).normalize() // 右・上方向
  },

  move: function () {
    this.position.add(this.direction)
  },

  reflectX: function () {
    this.direction.x *= -1
  },

  reflectY: function () {
    this.direction.y *= -1
  }
})

phina.define('Paddle', {
  superClass: 'RectangleShape',
  init: function () {
    this.superInit({
      width: PADDLE_WIDTH,
      height: PADDLE_HEIGHT,
      fill: 'white',
      stroke: null,
      cornerRadius: 8
    })
  },

  hold: function (ball) {
    this.ball = ball
  },

  release: function () {
    this.ball = null
  },

  update: function () {
    if (this.ball) {
      this.ball.x = this.x
      this.ball.y = this.top - this.ball.radius
    }
  }
})