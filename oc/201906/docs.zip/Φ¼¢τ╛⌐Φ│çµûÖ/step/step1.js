phina.globalize()

const SCREEN_WIDTH = 640
const SCREEN_HEIGHT = 960
const MAX_PER_LINE = 8
const BLOCK_NUM = MAX_PER_LINE * 5
const BLOCK_SIZE = 64
const BOARD_PADDING = 50
const PADDLE_WIDTH = 150
const PADDLE_HEIGHT = 32
const BALL_RADIUS = 16
const BALL_SPEED = 16

const BOARD_SIZE = SCREEN_WIDTH - BOARD_PADDING * 2
const BOARD_OFFSET_X = BOARD_PADDING + BLOCK_SIZE / 2
const BOARD_OFFSET_Y = 150

phina.define('MainScene', {
  superClass: 'DisplayScene',
  init: function () {
    this.superInit()

    // --- ↓ Step.3 のコードを記述する
    // --- ↑ Step.3 ここまで


    // --- ↓ Step.6 のコードを記述する
    // --- ↑ Step.6 ここまで
  },

  // --- ↓ Step.7 のコードを記述する
  // --- ↑ Step.7 ここまで

  // --- ↓ Step.8 のコードを記述する
  // --- ↑ Step.8 ここまで
})

// --- ↓ Step.2 のコードを記述する
// --- ↑ Step.2 ここまで


// --- ↓ Step.5 のコードを記述する
// --- ↑ Step.5 ここまで

phina.main(function () {
  GameApp({
    fps: 30,
    title: 'Game',
    startLabel: 'main',
    width: SCREEN_WIDTH,
    height: SCREEN_HEIGHT,
    backgroundColor: '#444'
  })
    .run()
})
