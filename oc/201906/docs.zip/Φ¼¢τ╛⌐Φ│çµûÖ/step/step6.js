    // ボール
    this.ball = Ball().addChildTo(this)

    // パドル
    this.paddle = Paddle().addChildTo(this)
    this.paddle.setPosition(this.gridX.center(), this.gridY.span(15))
    this.paddle.hold(this.ball)

    // 最初のタップでスタート
    this.ballSpeed = 0
    this.one('pointend', () => {
      this.paddle.release()
      this.ballSpeed = BALL_SPEED
    })