phina.globalize()

const SCREEN_WIDTH = 640
const SCREEN_HEIGHT = 960
const MAX_PER_LINE = 8
const BLOCK_NUM = MAX_PER_LINE * 5
const BLOCK_SIZE = 64
const BOARD_PADDING = 50
const PADDLE_WIDTH = 150
const PADDLE_HEIGHT = 32
const BALL_RADIUS = 16
const BALL_SPEED = 16

const BOARD_SIZE = SCREEN_WIDTH - BOARD_PADDING * 2
const BOARD_OFFSET_X = BOARD_PADDING + BLOCK_SIZE / 2
const BOARD_OFFSET_Y = 150

const ASSETS = {
  sound: {
    bgm: 'https://hamasyou-dhw.github.io/oc/201906/assets/stage.mp3'
  }
}

phina.define('MainScene', {
  superClass: 'DisplayScene',
  init: function (options) {
    this.superInit(options)

    this.gameLayer = DisplayElement().addChildTo(this)
    this.uiLayer = DisplayElement().addChildTo(this)

    // スコアラベル
    this.scoreLabel = Label({text: '0', fill: 'white'}).addChildTo(this.uiLayer)
    this.scoreLabel.setPosition(this.gridX.center(), this.gridY.span(1))

    // BGM 再生
    let isBgmStarted = false
    this.bgmButton = Button({text: "BGM ON", fontSize: 12, width: 60, height: 24}).addChildTo(this.uiLayer)
    this.bgmButton.setPosition(this.gridX.span(1), this.gridY.span(1))
    this.bgmButton.onpointend = () => {
      isBgmStarted = !isBgmStarted

      if (isBgmStarted) {
        this.bgm = SoundManager.playMusic('bgm')
        this.bgmButton.text = "BGM OFF"
      } else {
        SoundManager.stopMusic(0)
        this.bgmButton.text = "BGM ON"
      }
    }


    this.group = DisplayElement().addChildTo(this.gameLayer)

    var gridX = Grid(BOARD_SIZE, MAX_PER_LINE)
    var gridY = Grid(BOARD_SIZE, MAX_PER_LINE)

    // ブロックの表示
    ;(BLOCK_NUM).times((i) => {
      let x = i % MAX_PER_LINE
      let y = Math.floor(i / MAX_PER_LINE)
      let angle = 360 / BLOCK_NUM * i
      let block = Block(angle).addChildTo(this.group)

      block.x = gridX.span(x) + BOARD_OFFSET_X
      block.y = gridY.span(y) + BOARD_OFFSET_Y
    })

    // ボール
    this.ball = Ball().addChildTo(this.gameLayer)

    // パドル
    this.paddle = Paddle().addChildTo(this.gameLayer)
    this.paddle.setPosition(this.gridX.center(), this.gridY.span(15))
    this.paddle.hold(this.ball)

    // スコア
    this.score = 0

    // 最初のタップでスタート
    this.ballSpeed = 0
    this.one('pointend', () => {
      this.paddle.release()
      this.ballSpeed = BALL_SPEED
    })
  },

  update: function (app) {
    this.paddle.x = app.pointer.x
    if (this.paddle.left < 0) {
      this.paddle.left = 0
    } else if (this.paddle.right > this.gridX.width) {
      this.paddle.right = this.gridX.width
    }

    ;(this.ballSpeed).times(() => {
      this.ball.move()
      this.checkHit()
    })
  },

  checkHit: function () {
    if (this.ball.left < 0) {
      this.ball.left = 0
      this.ball.reflectX()
    } else if (this.ball.right > this.gridX.width) {
      this.ball.right = this.gridX.width
      this.ball.reflectX()
    }

    if (this.ball.top < 0) {
      this.ball.top = 0
      this.ball.reflectY()
    } else if (this.ball.bottom > this.gridY.width) {
      this.ball.bottom = this.gridY.width
      this.ball.reflectY()
      this.gameOver()
    }

    // パドルとボールの接触
    if (this.ball.hitTestElement(this.paddle)) {
      this.ball.bottom = this.paddle.top

      let dx = this.ball.x - this.paddle.x
      this.ball.direction.x = dx
      this.ball.direction.y = -60
      this.ball.direction.normalize()

      // ボールのスピードアップ
      this.ballSpeed += 1
    }

    // ブロック
    this.group.children.some((block) => {
      if (this.ball.hitTestElement(block)) {
        // ベクトルの引き算（ボールの方向を計算）
        let dq = Vector2.sub(this.ball, block)

        if (Math.abs(dq.x) < Math.abs(dq.y)) {
          this.ball.reflectY()
          if (dq.y >= 0) {
            this.ball.top = block.bottom
          } else {
            this.ball.bottom = block.top
          }
        } else {
          this.ball.reflectX()
          if (dq.x >= 0) {
            this.ball.left = block.right
          } else {
            this.ball.right = block.left
          }
        }

        // ブロックを取り除く
        block.remove()

        // スコア加算
        this.score += 100

        return true
      }
    }, this)
  },

  gameOver: function () {
    this.exit({
      score: this.score
    })
  },

  _accessor: {
    score: {
      get: function () {
        return this._score
      },
      set: function (val) {
        this._score = val
        this.scoreLabel.text = val
      }
    }
  }
})

phina.define('Block', {
  superClass: 'RectangleShape',
  init: function (angle) {
    this.superInit({
      width: BLOCK_SIZE,
      height: BLOCK_SIZE,
      fill: 'hsl({0}, 80%, 60%)'.format(angle || 0),
      stroke: null,
      cornerRadius: 8
    })
  }
})

phina.define('Ball', {
  superClass: 'CircleShape',
  init: function () {
    this.superInit({
      radius: BALL_RADIUS,
      fill: 'white',
      stroke: null,
      cornerRadius: 8
    })
    this.speed = 0
    this.direction = Vector2(1, -1).normalize() // 右・上方向
  },

  move: function () {
    this.position.add(this.direction)
  },

  reflectX: function () {
    this.direction.x *= -1
  },

  reflectY: function () {
    this.direction.y *= -1
  }
})

phina.define('Paddle', {
  superClass: 'RectangleShape',
  init: function () {
    this.superInit({
      width: PADDLE_WIDTH,
      height: PADDLE_HEIGHT,
      fill: 'white',
      stroke: null,
      cornerRadius: 8
    })
  },

  hold: function (ball) {
    this.ball = ball
  },

  release: function () {
    this.ball = null
  },

  update: function () {
    if (this.ball) {
      this.ball.x = this.x
      this.ball.y = this.top - this.ball.radius
    }
  }
})

phina.main(function () {
  GameApp({
    fps: 30,
    title: 'Game',
    // startLabel: 'main',
    startLabel: 'title',
    width: SCREEN_WIDTH,
    height: SCREEN_HEIGHT,
    backgroundColor: '#444',
    assets: ASSETS
  })
    .enableStats()
    .run()
})
