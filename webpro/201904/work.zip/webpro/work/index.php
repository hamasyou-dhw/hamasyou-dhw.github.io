<!doctype html>
<html>
<head>
  <meta content="utf-8">
</head>
<body>
<h1>演習用 ECサイト</h1>
<?php include_once '_menu.tpl.php'; ?>
</body>
</html>
