<?php
  require_once 'model/shopping_cart.php';
  require_once 'model/product.php';
  require_once 'util.php';
