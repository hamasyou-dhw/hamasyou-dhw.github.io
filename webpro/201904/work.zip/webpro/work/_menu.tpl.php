<ul>
  <li><a href="register.php">商品登録(register.php)</a></li>
  <li><a href="list.php">商品一覧(list.php)</a></li>
  <li><a href="cart.php">カート(cart.php)</a></li>
</ul>
