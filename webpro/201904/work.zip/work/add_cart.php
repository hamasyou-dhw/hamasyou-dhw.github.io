<?php
  // カート機能はセッションを使う
  session_start();
  require_once 'util.php';

  if ( isset($_POST['product_id']) ) {
    $id = $_POST['product_id'];
    add_cart_for_item_id($id);
    redirect_to('cart.php');
  } else {
    echo '商品を選択してください。';
  }
