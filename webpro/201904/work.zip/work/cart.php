<?php
  session_start();
  require_once 'util.php';

  $items = read_csv_for_item('data/items.csv');
  $item_ids = get_item_ids_from_cart();

  // ID が一致する商品を表示
  function cart_item($var) {
    global $item_ids;
    return in_array($var['id'], $item_ids);
  }

  function map_price($var) {
    return $var['price'];
  }

  $items = array_filter($items, 'cart_item');
  $item_prices = array_map('map_price', $items);
  $total_price = array_sum($item_prices);
?>
<!doctype html>
<html>
<head>
<meta content="utf-8">
</head>
<body>
<h1>カート画面</h1>
<div>
<?php
  if (count($items) == 0) {
    echo 'カートに商品が入っていません。';
  } else {
    include '_items.tpl.php';
  }
?>
<div>
<h3>合計金額:
<?= $total_price ?>円
</h3>
</div>

<?php include_once '_menu.tpl.php'; ?>
</div>
</body>
</html>
