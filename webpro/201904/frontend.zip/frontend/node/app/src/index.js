import { hello } from './sub'

hello()
